var x = +prompt("enter first number: ")
var y = +prompt("enter second number: ")
var z = +prompt("enter third number: ")


var result1 = x + x + y;

var result2 = x ** (y - z)

var result3 = x % y

var result4 = y + z - x

var result5 = x + (y ** z)


alert(result1)