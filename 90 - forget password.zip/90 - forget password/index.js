var usersData = [
    {id: 1, username: 'mohammad', password: 'mohammad156315', email: 'mohammad@gmail.com'},
    {id: 2, username: 'sasan', password: 'sasan858', email: 'sasan@gmail.com'},
    {id: 3, username: 'ahmad', password: 'ahmad6315', email: 'ahmad@gmail.com'},
    {id: 4, username: 'ehsan', password: 'ehsannn44', email: 'ehsan@gmail.com'},
    {id: 5, username: 'mostafa', password: 'mostafa758', email: 'mostafa@gmail.com'},
    {id: 6, username: 'mahan', password: 'mahan@4525', email: 'mahan@gmail.com'}
];

let username = prompt("enter your userName");

let mainUserData = usersData.find(function(user){
    return user.username === username;
});

if(mainUserData === undefined){
    alert("invalid userName");
} else {
    alert("your password is: " + mainUserData.password);
}

console.log(mainUserData);
