

let toDoArrays = [
    {id: 1, title:"read java script", isDoing:false},
    {id: 2, title:"read node js", isDoing:false},
    {id: 3, title:"listen to podcast", isDoing:false},
];

let userMenu = prompt("choose one of them: \n 1. Add ToDo \n 2. remove ToDo \n 3. Do ToDo");

if(userMenu === "1") {
    let newToDoName = prompt("enter new todo name");
    let newToDoObject = {
        id : toDoArrays.length + 1,
        title : newToDoName,
        isDoing : false,
    };
    toDoArrays.push(newToDoObject);
    console.log(toDoArrays);
} else if(userMenu === "2") {
    let removeToDoName = prompt("enter the removable todo name");
    let removableToDoIndex = toDoArrays.findIndex(function(todo){
        return todo.title === removeToDoName;
    });
    toDoArrays.splice(removableToDoIndex, 1);
    console.log(toDoArrays);
} else if(userMenu === "3") {
    let editableToDoName = prompt("enter the editable todo name");
    toDoArrays.forEach(function(todo){
        if(todo.title === editableToDoName){
            todo.isDoing = true;
        }
    });
    console.log(toDoArrays);
} else {
    alert("invalid number");
}
