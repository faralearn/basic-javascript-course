var grade = +prompt("معدلتو وارد کن:");

if (grade <= 20 && grade > 17) {
    console.log("تبریک!!! معدلت خیلی خوبه!");
} else if (grade <= 17 && grade > 15) {
    console.log("معدلت بدک نیست ولی میتونه بهترم بشه");
} else if (grade <= 15 && grade > 10) {
    console.log("اصلا!!! معدل قابل تعریفی نداری!!! یکم بیشتر درستو بخون");
} else if (grade <= 10 && grade >= 0) {
    console.log("اینم نمرس!!!!! حرفی نمی مونه");
} else {
    console.log("نمره وارد شده معتبر نیست");
}
