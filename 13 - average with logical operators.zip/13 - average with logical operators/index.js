// first way


// var riyazi = +prompt("nomre riyazi ro vared konid(0 - 20)");
// var shimi = +prompt("nomre shimi ro vared konid(0 - 20)");
// var fizik = +prompt("nomre fizik ro vared konid(0 - 20)");
// var zaban = +prompt("nomre zaban ro vared konid(0 - 20)");


// var riyaziGrade = riyazi * 3;
// var shimiGrade = shimi * 2;
// var fizikGrade =fizik * 2;
// var zabanGrade =zaban * 1;


// var ave = (riyaziGrade + shimiGrade + fizikGrade + zabanGrade) / 8;

// alert(ave)







// second way


var riyazi = +prompt("nomre riyazi ro vared konid(0 - 20)");
var shimi = +prompt("nomre shimi ro vared konid(0 - 20)");
var fizik = +prompt("nomre fizik ro vared konid(0 - 20)");
var zaban = +prompt("nomre zaban ro vared konid(0 - 20)");


var ave = ((riyazi * 3) + (shimi * 2) + (fizik * 2) + (zaban)) / 8;

alert(ave)

