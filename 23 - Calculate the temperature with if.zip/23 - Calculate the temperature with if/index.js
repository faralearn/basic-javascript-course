var temp = +prompt("enter temp: ")

var f = (temp * (9/5) + 32);

if(f > 90){
    console.log("هشدار هوای گرم");
}else{
    console.log("هوای خنک"); 
}

console.log(f);
