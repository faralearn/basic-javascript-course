let cities = {
    tehran : ["tehran", "shahryar", "rudehen"],
    lorestan : ["khorramAbad", "azna", "aligodarz", "borujerd"],
    tabriz : ["tabriz", "jolfa", "marand"]
};

let startProvine = prompt("enter provine");

let maincity = cities[startProvine];

console.log(maincity);

maincity.forEach(function(city){
    console.log(city);
});
