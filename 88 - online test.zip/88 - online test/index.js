let AllQuestions = [
    {id: 1, title: "2 + 2", answer: "4"},
    {id: 2, title: "4 * 8", answer: "32"},
    {id: 3, title: "4 - 2", answer: "2"},
    {id: 4, title: "20 / 4", answer: "5"},
    {id: 5, title: "100 / 20", answer: "5"},
    {id: 6, title: "framework of javascript(react js or django)", answer: "react"}
];

let score = 0;
let mainAnswer = "";

AllQuestions.forEach(function(question){
    mainAnswer = prompt(question.title + "?");
    if(mainAnswer === question.answer){
        score++;
    }
});

alert("your score is: " + score);
