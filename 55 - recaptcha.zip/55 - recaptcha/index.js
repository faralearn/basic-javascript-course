

var randomNumber = Math.random() * 1000000;

var finalRandom = Math.floor(randomNumber)

console.log(finalRandom);
