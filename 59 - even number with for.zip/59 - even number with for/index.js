
// first way

// for (let x = 0 ; x <= 100 ; x+=2 ){
//     console.log(x);
// }






// second way

for (let x = 0 ; x <= 100 ; x++ ){
    if(x%2 == 0){
        console.log(x);   
    }
}