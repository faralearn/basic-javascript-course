


let users = [
    {id: 1, name: "mohammad", family: "beigi", age: 30, email: "mohammad@gmail.com"},
    {id: 2, name: "ali", family: "ahmadi", age: 35, email: "ali@gmail.com"},
    {id: 3, name: "reza", family: "rezaei", age: 20, email: "reza@gmail.com"},
];

let userName = prompt("enter your name");
let userFamilyName = prompt("enter your last name");
let userAge = +prompt("enter your age");
let userGmail = prompt("enter your Gmail");

if (userName.length < 3 || userName.length > 10) {
    console.log("username error");
} else if (userFamilyName.length < 3 || userFamilyName.length > 15) {
    console.log("user family name error");
} else if (userAge < 0 || userAge > 100) {
    console.log("user age error");
} else if (userGmail.slice(-10) != "@gmail.com") {
    console.log("gmail error");
} else {
    let newUser = {
        id: 4,
        name: userName,
        familyName: userFamilyName,
        age: userAge,
        gmail: userGmail,
    };
    users.push(newUser)
}

console.log(users);