


let sum = 0;

let number = 0;

do {
    sum += number;  // جمع کردن مقدار وارد شده به متغیر sum
    number = +prompt("enter number");
} while (number >= 0);

console.log("sum is: " + sum);
