


var firstNumber = +prompt("enter first number");
var secondNumber = +prompt("enter second number");

var sum = 0;
for (let i = firstNumber ; i <= secondNumber ; i++) {
    sum = sum + i;
}

console.log(sum);
