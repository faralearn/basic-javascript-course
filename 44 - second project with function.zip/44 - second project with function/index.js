

var userName = prompt("enter your name");

if (userName.toLowerCase() == "ali") {
    console.log("valid user");
} else {
    console.log("invalid user");
}
