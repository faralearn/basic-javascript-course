var age = +prompt("سن خودت رو برحسب سال میلادی وارد کن: ")

var nowAge = 2023 - age;
var monthAge = nowAge * 12


if(nowAge > 18){
    console.log("شما با موفقیت وارد شدید.");
}else{
    console.log("شما اجازه ورود به سایت را ندارید.");
    
}


console.log("your age is " + nowAge + " years old");
console.log("month is: " + monthAge);

