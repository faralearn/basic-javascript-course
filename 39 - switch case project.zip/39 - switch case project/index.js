var monthNumber = +prompt("عدد ماه را وارد کنید: ")
var season;

switch(monthNumber){
    case 1:
    case 2:
    case 3:
        season = "بهار";
        break;


    case 4:
    case 5:
    case 6:
        season = "تابستان";
        break;
        
        

    case 7:
    case 8:
    case 9:
        season = "پاییز";
        break;
        
        
    case 10:
    case 11:
    case 12:
        season = "زمستان";
        break;
        
        
    default:
        season = "عدد ماه وارد شده معتبر نیست."
}


console.log(season);




