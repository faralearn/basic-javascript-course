

let word = prompt("enter your word");  // "ahmad"

let changeToArray = word.split("");

let reverceArray = changeToArray.reverse();

let convertToString = reverceArray.join("");  // "dahma"

if (word === convertToString) {
    console.log("ok");
} else {
    console.log("error");
}

console.log(word);
console.log(convertToString);
