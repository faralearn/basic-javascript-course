


let userBasket = [
    {id: 1, name: "samsung phone", price: 100000},
    {id: 2, name: "acer laptop", price: 1000000},
    {id: 3, name: "apple phone", price: 600000},
    {id: 4, name: "samsung laptop", price: 400000},
    {id: 5, name: "sony laptop", price: 800000},
    {id: 6, name: "sony phone", price: 200000}
];

let filterProduct = userBasket.filter(function(product){
    return product.price < 500000;
});

let postCost = filterProduct.length * 50000;  // 150000

let sum = 0;

userBasket.forEach(function(product){
    sum += product.price;
});

let totalPrice = sum + postCost;

console.log("total price without post is: " + sum);
console.log("total price with post is: " + totalPrice);

