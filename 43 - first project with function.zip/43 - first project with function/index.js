

function zoujYaFard(number) {
    if (number % 2 === 0) {
        console.log("عدد " + number + " زوج است");
    } else {
        console.log("عدد " + number + " فرد است");
    }
}

zoujYaFard(20);
zoujYaFard(21);
zoujYaFard(100);
