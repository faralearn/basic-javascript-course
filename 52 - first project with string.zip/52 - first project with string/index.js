

function average(programmerGrade, mathGrade, englishGrade) {
    var ave = ((programmerGrade * 3) + (mathGrade * 2) + (englishGrade * 1)) / 6;
    console.log("my average is: " + ave);

    if (ave >= 17) {
        console.log("معدل برتر");
    } else {
        console.log("معدل معمولی");
    }
}

average(20, 15, 10);
average(20, 15, 20);
average(20, 10, 20);
