var age = +prompt("سن خود را وارد کنید: ");

if(age > 18){
    console.log("با موفقیت وارد شدید");
}else{
    console.log("شما اجازه ورود به سایت را ندارید");
}