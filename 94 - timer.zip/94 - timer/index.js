let min = prompt("enter min");
let sec = prompt("enter sec");

let timer = setInterval(function() {
    if(sec === -1) {
        min--;
        sec = 59;
    }

    if(min === 0 && sec === 0) {
        clearInterval(timer);
        alert("finish");
    }

    console.log(min + ":" + sec);
    sec--;
}, 1000);
