



let users = [
    {id: 1, name: "mohammad", lastName: "beigi", age: 30},
    {id: 2, name: "ali", lastName: "ahmadi", age: 33},
    {id: 3, name: "reza", lastName: "abbasi", age: 22}
];

users.forEach(function(item) {
    console.log("my name is " + item.name + " and my last name is: " + item.lastName + " and I'm " + item.age + " years old.");
});
