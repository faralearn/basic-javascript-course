


var userNumber = 0;
var sum = 0;
var counter = 0;

while(userNumber != -1) {
    sum += userNumber;  // جمع کردن مقدار وارد شده به متغیر sum

    userNumber = +prompt("enter number (enter -1 to exit)");

    if(userNumber != -1){
        counter++;
    }
}

console.log("sum is: " + sum);
console.log("counter is: " + counter);

console.log("average is: " + sum/counter);
