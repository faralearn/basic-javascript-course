


let userNumbers = [];
let sum = 0;
let userNumber = 0;

while (userNumber != -1) {
    userNumber = +prompt("enter a number (enter -1 to exit)");
    if (userNumber != -1) {
        userNumbers.push(userNumber);
    }
}

for (let i = 0; i < userNumbers.length; i++) {
    sum += userNumbers[i];
}

console.log(userNumbers);
console.log(sum);
console.log("the average is: " + sum / userNumbers.length);
