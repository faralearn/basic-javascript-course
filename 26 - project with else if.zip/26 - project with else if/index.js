// var job = prompt("وضعیت شغلی خود را وارد کنید:");
var job = confirm("آیا شاغل هستین؟")
var jensiyat = prompt("جنسیت خود را وارد کنید:");
var age = prompt("سن خود را وارد کنید:");
var name = prompt("نام خود را وارد کنید:");

if (jensiyat == "male") {
    if (job) {
        if (age > 18) {
            console.log("جناب آقای " + name + " شما با موفقیت وارد سایت شدین.");
        } else if (age < 18) {
            console.log("جناب آقای " + name + " دسترسی به خدمات سایت باید بیشتر از 18 سال سن داشته باشید.");
        }
    } else {
        console.log("شما مجوز ورود به سایت را ندارید.");
    }
} else if (jensiyat == "female") {
    if (job) {
        if (age > 18) {
            console.log("سرکار خانم " + name + " شما با موفقیت وارد سایت شدین.");
        } else if (age < 18) {
            console.log("سرکار خانم " + name + " دسترسی به خدمات سایت باید بیشتر از 18 سال سن داشته باشید.");
        }
    } else {
        console.log("شما مجوز ورود به سایت را ندارید.");
    }
}

