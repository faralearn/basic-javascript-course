

var firstNumber = +prompt("enter first number");
var secondNumber = +prompt("enter second number");


var sum = 0;
var i = firstNumber;

while(i <= secondNumber){
    sum = sum + i;
    i++;
}

console.log(sum);
