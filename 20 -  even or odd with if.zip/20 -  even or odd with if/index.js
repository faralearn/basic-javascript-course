var number = +prompt("enter your number: ")

if(number % 2 == 0){
    console.log("عدد وارد شده زوج است");
}else{
    console.log("عدد وارد شده فرد است");
    
}