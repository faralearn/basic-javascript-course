




var sum = 0;

for (let i = 1; i < 7; i++) {
    var numbers = +prompt("enter number " + i);
    sum = sum + numbers;
    console.log(sum);
}
var ave = sum / 6;

console.log("average is " + ave);
