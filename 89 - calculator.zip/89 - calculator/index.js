let num1 = +prompt("enter first number");
let num2 = +prompt("enter second number");

let userOperator = prompt("enter the operator: \n 1. + \n 2. - \n 3. * \n 4. / \n 5. **");

if(userOperator === "1") {
    sum(num1, num2);
} else if(userOperator === "2") {
    tafrigh(num1, num2);
} else if(userOperator === "3") {
    zarb(num1, num2);
} else if(userOperator === "4") {
    devide(num1, num2);
} else if(userOperator === "5") {
    power(num1, num2);
} else {
    alert("invalid operator");
}

function sum(num1, num2) {
    alert(num1 + num2);
}

function tafrigh(num1, num2) {
    alert(num1 - num2);
}

function devide(num1, num2) {
    alert(num1 / num2);
}

function zarb(num1, num2) {
    alert(num1 * num2);
}

function power(num1, num2) {
    alert(num1 ** num2);
}
