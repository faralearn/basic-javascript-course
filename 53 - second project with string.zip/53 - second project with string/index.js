

var phoneNumber = prompt("enter your phone number");

console.log(phoneNumber);

if (phoneNumber.length === 11 && phoneNumber.startsWith("09")) {
    var middleNumbers = phoneNumber.slice(4, 8);

    var finalNumber = phoneNumber.replace(middleNumbers, "****");
    console.log("your number is " + finalNumber);

    console.log("your phone number is valid");
} else {
    console.log("your phone number is invalid");
}
