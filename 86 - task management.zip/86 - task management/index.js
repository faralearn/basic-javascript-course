let taskArray = {
    ali: ["seo", "google ads"],
    mohammad: ["html", "css"],
    babak: ["bootstrap", "tailwind"],
    sasan: ["react js", "vue js", "angular js"]
};

let newTaskName = prompt("enter new task");
let programmingName = prompt("enter the programmer");

let programmingTask = taskArray[programmingName];

programmingTask.push(newTaskName);

console.log(taskArray);
