var programmingGrage = +prompt("enter your programming grade:");
var mathgGrage = +prompt("enter your math grade:");
var englishGrage = +prompt("enter your english  grade:");


var ave = ((programmingGrage * 3) + (mathgGrage * 2) + (englishGrage + 1)) / 6;


if(ave > 17){
    console.log("معدل برتر");
}else{
    console.log("معدل معمولی");
    
}



console.log(programmingGrage);
console.log(mathgGrage);
console.log(englishGrage);
console.log(ave);



